import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from tkinter import simpledialog

# Inicializa a janela principal
root = tk.Tk()
root.title("Cadastro de Usuários")

# Dicionário para armazenar os usuários
usuarios = {}

# Função para adicionar um novo usuário
def cadastrar_usuario():
    form_window = tk.Toplevel(root)
    form_window.title("Cadastro de Usuário")

    nome_label = tk.Label(form_window, text="Nome:")
    nome_label.pack()
    nome_entry = tk.Entry(form_window)
    nome_entry.pack()

    idade_label = tk.Label(form_window, text="Idade:")
    idade_label.pack()
    idade_entry = tk.Entry(form_window)
    idade_entry.pack()

    cpf_label = tk.Label(form_window, text="CPF:")
    cpf_label.pack()
    cpf_entry = tk.Entry(form_window)
    cpf_entry.pack()

    cargo_label = tk.Label(form_window, text="Cargo:")
    cargo_label.pack()
    cargo_entry = tk.Entry(form_window)
    cargo_entry.pack()

    salario_label = tk.Label(form_window, text="Salário:")
    salario_label.pack()
    salario_entry = tk.Entry(form_window)
    salario_entry.pack()

    telefone_label = tk.Label(form_window, text="Telefone:")
    telefone_label.pack()
    telefone_entry = tk.Entry(form_window)
    telefone_entry.pack()

    def salvar_cadastro():
        nome = nome_entry.get()
        idade = idade_entry.get()
        cpf = cpf_entry.get()
        cargo = cargo_entry.get()
        salario = salario_entry.get()
        telefone = telefone_entry.get()

        if nome and idade and cpf and cargo and salario and telefone:
            # Adicionar os dados a um dicionário de usuários
            usuarios[cpf] = [nome, idade, cpf, cargo, float(salario), telefone]
            messagebox.showinfo("Cadastro de Usuário", "Usuário cadastrado com sucesso!")
            form_window.destroy()
        else:
            messagebox.showerror("Erro", "Todos os campos devem ser preenchidos!")

    salvar_button = tk.Button(form_window, text="Salvar", command=salvar_cadastro)
    salvar_button.pack()

# Função para fazer lançamentos
def fazer_lancamento(credito=False):
    cpf = simpledialog.askstring("Lançamento de Crédito" if credito else "Lançamento de Débito", "Digite o CPF:")
    if cpf:
        if cpf in usuarios:
            salario = usuarios[cpf][4]
            valor = simpledialog.askfloat("Lançamento de Crédito" if credito else "Lançamento de Débito", f"Salário atual: {salario}\nDigite o valor:")
            if valor is not None:
                if credito:
                    usuarios[cpf][4] += valor
                else:
                    usuarios[cpf][4] -= valor
                messagebox.showinfo("Lançamento", f"Lançamento efetuado com sucesso! Saldo atual: {usuarios[cpf][4]}")
        else:
            messagebox.showinfo("Lançamento", "Nenhum usuário encontrado com esse CPF.")
    else:
        messagebox.showerror("Erro", "Digite um CPF válido!")

# Função para listar usuários
def listar_usuarios(ordem_alfabetica=False, listar_debitos=False, listar_creditos=False):
    if not usuarios:
        messagebox.showinfo("Lista de Usuários", "Não há usuários cadastrados.")
        return

    if ordem_alfabetica:
        usuarios_ordenados = sorted(usuarios.values(), key=lambda usuario: usuario[0].lower())
    else:
        usuarios_ordenados = list(usuarios.values())

    if listar_debitos:
        resultado = [usuario for usuario in usuarios_ordenados if usuario[4] < 0]
    elif listar_creditos:
        resultado = [usuario for usuario in usuarios_ordenados if usuario[4] > 0]
    else:
        resultado = usuarios_ordenados

    if resultado:
        result_window = tk.Toplevel(root)
        result_window.title("Lista de Usuários")

        result_tree = ttk.Treeview(result_window, columns=("Nome", "Idade", "CPF", "Cargo", "Salário", "Telefone"))
        result_tree.heading("#1", text="Nome")
        result_tree.heading("#2", text="Idade")
        result_tree.heading("#3", text="CPF")
        result_tree.heading("#4", text="Cargo")
        result_tree.heading("#5", text="Salário")
        result_tree.heading("#6", text="Telefone")

        for usuario in resultado:
            result_tree.insert("", "end", values=usuario)

        result_tree.pack()
    else:
        messagebox.showinfo("Lista de Usuários", "Nenhum usuário encontrado com os critérios selecionados.")

# Função para pesquisar por CPF
def pesquisar_por_cpf():
    cpf = simpledialog.askstring("Pesquisa por CPF", "Digite o CPF:")
    if cpf:
        if cpf in usuarios:
            mostrar_resultados([usuarios[cpf]])
        else:
            messagebox.showinfo("Pesquisa por CPF", "Nenhum usuário encontrado com esse CPF.")
    else:
        messagebox.showerror("Erro", "Digite um CPF válido!")

# Função para pesquisar por nome
def pesquisar_por_nome():
    nome = simpledialog.askstring("Pesquisa por Nome", "Digite o Nome:")
    if nome:
        resultados = [usuario for usuario in usuarios.values() if nome.lower() in usuario[0].lower()]
        if resultados:
            mostrar_resultados(resultados)
        else:
            messagebox.showinfo("Pesquisa por Nome", "Nenhum usuário encontrado com esse nome.")
    else:
        messagebox.showerror("Erro", "Digite um nome válido!")

# Função para exibir os resultados da pesquisa
def mostrar_resultados(resultados):
    result_window = tk.Toplevel(root)
    result_window.title("Resultados da Pesquisa")

    result_tree = ttk.Treeview(result_window, columns=("Nome", "Idade", "CPF", "Cargo", "Salário", "Telefone"))
    result_tree.heading("#1", text="Nome")
    result_tree.heading("#2", text="Idade")
    result_tree.heading("#3", text="CPF")
    result_tree.heading("#4", text="Cargo")
    result_tree.heading("#5", text="Salário")
    result_tree.heading("#6", text="Telefone")

    for usuario in resultados:
        result_tree.insert("", "end", values=usuario)

    result_tree.pack()

# Função para deletar um usuário por CPF
def deletar_por_cpf():
    cpf = simpledialog.askstring("Excluir Usuário", "Digite o CPF do usuário a ser excluído:")
    if cpf:
        if cpf in usuarios:
            del usuarios[cpf]
            messagebox.showinfo("Excluir Usuário", "Usuário excluído com sucesso!")
        else:
            messagebox.showinfo("Excluir Usuário", "Nenhum usuário encontrado com esse CPF.")
    else:
        messagebox.showerror("Erro", "Digite um CPF válido!")

# Função para sair do programa
def sair():
    root.quit()

# Criação do menu
menu = tk.Menu(root)
root.config(menu=menu)

# Menu Cadastros
cadastros_menu = tk.Menu(menu)
menu.add_cascade(label="Cadastro Usuário", menu=cadastros_menu)
cadastros_menu.add_command(label="Usuário", command=cadastrar_usuario)

# Menu Lançamentos
lancamentos_menu = tk.Menu(menu)
menu.add_cascade(label="Lançamentos", menu=lancamentos_menu)
lancamentos_menu.add_command(label="Crédito", command=lambda: fazer_lancamento(credito=True))
lancamentos_menu.add_command(label="Débito", command=lambda: fazer_lancamento())

# Menu Listar
listar_menu = tk.Menu(menu)
menu.add_cascade(label="Listar", menu=listar_menu)
listar_menu.add_command(label="Ordem Alfabética", command=lambda: listar_usuarios(ordem_alfabetica=True))
listar_menu.add_command(label="Débitos", command=lambda: listar_usuarios(listar_debitos=True))
listar_menu.add_command(label="Créditos", command=lambda: listar_usuarios(listar_creditos=True))

# Menu Pesquisa
pesquisa_menu = tk.Menu(menu)
menu.add_cascade(label="Pesquisa", menu=pesquisa_menu)
pesquisa_menu.add_command(label="CPF", command=pesquisar_por_cpf)
pesquisa_menu.add_command(label="Nome", command=pesquisar_por_nome)

# Menu Excluir
excluir_menu = tk.Menu(menu)
menu.add_cascade(label="Excluir", menu=excluir_menu)
excluir_menu.add_command(label="CPF", command=deletar_por_cpf)

# Menu Sair
menu.add_command(label="Sair", command=sair)

root.mainloop()